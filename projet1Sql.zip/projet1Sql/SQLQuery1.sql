use BDTP1Guelleh_Marrero

delete from Utilisateur where NoUtilisateur = @noUtilisateur



select * from Utilisateur
select * from TypeUtilisateur

update Utilisateur set NomUtilisateur = 'gabo' where NomUtilisateur = 'gab'


