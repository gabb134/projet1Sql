﻿namespace projet1BD3
{


    partial class BDTP1Guelleh_MarreroDataSet
    {
    }
}

namespace projet1BD3.BDTP1Guelleh_MarreroDataSetTableAdapters {
    
    
    public partial class PlanifSoinTableAdapter {
    }
}
